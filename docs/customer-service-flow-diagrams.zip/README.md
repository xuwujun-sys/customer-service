# 客服后端关键流程图

这些图根据当前 `customer-service` 源码和 YAML Flow 配置整理。

- `.mmd`：Mermaid 源文件，可继续编辑
- `.svg`：矢量图，适合插入 Markdown、Word、PPT
- `.png`：2 倍清晰度位图，适合直接预览和分享

1. `01-system-architecture`：系统组件与外部依赖
2. `02-message-lifecycle`：一条消息从请求到持久化的完整生命周期
3. `03-turn-planner`：Prompt 构造、LLM 输出、Validator 和三轨分流
4. `04-object-message`：订单/商品对象保存、匹配槽位和澄清
5. `05-task-execution`：CommandProcessor、FlowExecutor、ActionRunner
6. `06-slot-collection-sequence`：跨两次 HTTP 请求收集订单号
7. `07-task-interrupt-resume`：用户任务打断、暂停和恢复
8. `08-knowledge-flow`：知识意图、Provider、Chunk 和回答生成
9. `09-configured-business-flows`：当前 YAML 中配置的全部用户业务 Flow

说明：图中明确标出了当前源码中的占位能力，包括真实退款提交、FAQ/RAG 和人工客服集成。

## 快速预览

- [系统总体架构](01-system-architecture.svg)
- [消息完整生命周期](02-message-lifecycle.svg)
- [TurnPlanner 规划与校验](03-turn-planner.svg)
- [对象消息与自动补槽](04-object-message.svg)
- [TaskHandler 工作流执行](05-task-execution.svg)
- [跨请求槽位收集时序](06-slot-collection-sequence.svg)
- [任务打断与恢复](07-task-interrupt-resume.svg)
- [Knowledge 知识问答](08-knowledge-flow.svg)
- [当前已配置业务流程](09-configured-business-flows.svg)
